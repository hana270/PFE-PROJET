package com.example.gestionbassins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AquatresorApplicationTests {

	@Test
	void contextLoads() {
	}

}
