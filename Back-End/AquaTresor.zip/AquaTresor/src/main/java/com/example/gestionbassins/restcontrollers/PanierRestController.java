package com.example.gestionbassins.restcontrollers;

import com.example.gestionbassins.dto.*;
import com.example.gestionbassins.entities.*;
import com.example.gestionbassins.security.CustomUserDetails;
import com.example.gestionbassins.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

// Add this import
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Replace this incorrect import
// import java.net.http.HttpHeaders;
// With this correct import
import org.springframework.http.HttpHeaders;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/panier")
@CrossOrigin(origins = {"http://localhost:4200"}, 
    allowedHeaders = {"Authorization", "Content-Type", "X-Requested-With", "Accept", "Origin", "X-Session-ID"},
    exposedHeaders = {"Authorization", "X-Session-ID"},
    methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS},
    allowCredentials = "true")
public class PanierRestController {
    
    private final PanierService panierService;
    private final BassinService bassinService;
    private static final Logger logger = LoggerFactory.getLogger(PanierRestController.class);

    public PanierRestController(PanierService panierService, BassinService bassinService) {
        this.panierService = panierService;
        this.bassinService = bassinService;
    }

    private String generateSessionId() {
        return UUID.randomUUID().toString();
    }

    private PanierResponse mapToPanierResponse(Panier panier) {
        PanierResponse response = new PanierResponse();
        response.setId(panier.getIdPanier());
        
        // Check if user exists and use userId directly
        response.setUserId(panier.getUserId());
        
        response.setSessionId(panier.getSessionId());
        response.setTotalPrice(panier.getTotalPrice());

        if (panier.getItems() != null) {
            response.setItems(panier.getItems().stream()
                .map(this::convertToItemResponse)
                .collect(Collectors.toList()));
        } else {
            response.setItems(Collections.emptyList());
        }

        return response;
    }


   

    private BassinDTO convertToBassinDTO(Bassin bassin) {
        if (bassin == null) {
            return null;
        }

        BassinDTO dto = new BassinDTO();
        dto.setIdBassin(bassin.getIdBassin());
        dto.setNomBassin(bassin.getNomBassin());
        dto.setDescription(bassin.getDescription());
        dto.setPrix(bassin.getPrix());
        dto.setMateriau(bassin.getMateriau());
        dto.setCouleur(bassin.getCouleur());
        dto.setDimensions(bassin.getDimensions());
        dto.setDisponible(bassin.isDisponible());
        dto.setStock(bassin.getStock());
        dto.setImagePath(bassin.getImagePath());

        if (bassin.getImagesBassin() != null) {
            dto.setImagesBassin(bassin.getImagesBassin().stream()
                .map(ImageBassin::getImagePath)
                .collect(Collectors.toList()));
        }

        dto.setPromotionActive(bassin.hasActivePromotion());
        dto.setPrixPromo(bassin.getPrixPromotionnel());

        return dto;
    }
    
   
    @GetMapping
    public ResponseEntity<PanierResponse> getPanier(
            @RequestHeader(value = "X-Session-ID", required = false) String sessionId,
            HttpServletRequest request) {
        
        // Log headers for debugging
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            logger.info("Header {}: {}", headerName, request.getHeader(headerName));
        }
        
        Long userId = getCurrentUserId();
        
        if (userId == null && (sessionId == null || sessionId.isEmpty())) {
            sessionId = generateSessionId();
            logger.info("Generated new session ID: {}", sessionId);
        }

        Panier panier = panierService.getOrCreatePanier(userId, sessionId);
        PanierResponse response = mapToPanierResponse(panier);
        
        // Add session ID to response headers if new session was created
        HttpHeaders headers = new HttpHeaders();
        if (userId == null) {
            headers.add("X-Session-ID", panier.getSessionId());
        }
        
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

 
    @PutMapping("/items/{itemId}")
    public ResponseEntity<?> updateItemQuantity(
            @PathVariable Long itemId,
            @RequestBody Map<String, Integer> quantityMap,
            @RequestHeader(value = "X-Session-ID", required = false) String sessionId) {
        
        Integer newQuantity = quantityMap.get("quantity");
        if (newQuantity == null || newQuantity <= 0) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Quantité invalide"
            ));
        }

        try {
            Long userId = getCurrentUserId();
            panierService.updateItemQuantity(userId, sessionId, itemId, newQuantity);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Quantité mise à jour avec succès"
            ));
        } catch (Exception e) {
            logger.error("Error updating item quantity", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping("/items/{itemId}")
    public ResponseEntity<?> removeItem(
            @PathVariable Long itemId,
            @RequestHeader(value = "X-Session-ID", required = false) String sessionId) {
        
        try {
            Long userId = getCurrentUserId();
            panierService.removeItemFromPanier(userId, sessionId, itemId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Article supprimé du panier"
            ));
        } catch (Exception e) {
            logger.error("Error removing item from cart", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @DeleteMapping
    public ResponseEntity<?> clearPanier(
            @RequestHeader(value = "X-Session-ID", required = false) String sessionId) {
        
        try {
            Long userId = getCurrentUserId();
            panierService.clearPanier(userId, sessionId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Panier vidé avec succès"
            ));
        } catch (Exception e) {
            logger.error("Error clearing cart", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

   
    @GetMapping("/user/{user_id}")
    public ResponseEntity<PanierResponse> getPanierByUserId(@PathVariable("user_id") Long userId) {
        try {
            Panier panier = panierService.getPanierByUserId(userId);
            return ResponseEntity.ok(mapToPanierResponse(panier));
        } catch (Exception e) {
            logger.error("Error getting cart for user: " + userId, e);
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/user/{user_id}/add")
    public ResponseEntity<?> addToUserPanier(
            @PathVariable("user_id") Long userId,
            @RequestBody PanierItemRequest itemRequest) {
        
        try {
            PanierItem item = panierService.addItemToPanier(userId, null, itemRequest);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "item", convertToItemResponse(item)
            ));
        } catch (Exception e) {
            logger.error("Error adding item to user cart", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetails) {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            logger.info("Current User ID: {}", userDetails.getUserId());
            return userDetails.getUserId();
        }
        logger.warn("No authenticated user found or principal is not CustomUserDetails");
        return null;
    }
    
    private PanierItemResponse convertToItemResponse(PanierItem item) {
        Objects.requireNonNull(item, "PanierItem cannot be null");
        
        PanierItemResponse response = new PanierItemResponse();
        response.setId(item.getId());
        response.setQuantity(item.getQuantity());
        
        // Gestion du bassin
        if (item.getBassin() != null) {
            Bassin bassin = item.getBassin();
            response.setBassinId(bassin.getIdBassin());
            response.setBassin(convertToBassinDTO(bassin));
            
            double prixOriginal = bassin.getPrix();
            response.setPrixOriginal(prixOriginal);
            
            // Gestion promotion
            Optional.ofNullable(bassin.getPromotion())
                    .filter(promo -> bassin.hasActivePromotion())
                    .ifPresentOrElse(
                        promo -> applyPromotion(response, prixOriginal, promo),
                        () -> setRegularPrice(response, prixOriginal)
                    );
            
            response.setSubtotal(roundMoney(response.getEffectivePrice() * item.getQuantity()));
        } else {
            // Fallback pour items sans bassin
            setFallbackPrices(response, item);
        }
        
        // Gestion utilisateur
        response.setUserId(item.getPanier() != null ? item.getPanier().getUserId() : getCurrentUserId());
        
        return response;
    }

    // Méthodes helper
    private void applyPromotion(PanierItemResponse response, double prixOriginal, Promotion promo) {
        double tauxReduction = promo.getTauxReduction();
        double prixPromo = roundMoney(prixOriginal * (1 - tauxReduction));
        
        response.setPrixPromo(prixPromo);
        response.setEffectivePrice(prixPromo);
        response.setPromotionActive(true);
        response.setTauxReduction(tauxReduction);
        response.setNomPromotion(promo.getNomPromotion());
    }

    private void setRegularPrice(PanierItemResponse response, double prixOriginal) {
        response.setPrixPromo(prixOriginal);
        response.setEffectivePrice(prixOriginal);
        response.setPromotionActive(false);
    }

    private void setFallbackPrices(PanierItemResponse response, PanierItem item) {
        double prix = item.getPrixOriginal() != null ? item.getPrixOriginal() : 0;
        response.setPrixOriginal(prix);
        response.setEffectivePrice(item.getEffectivePrice() != null ? item.getEffectivePrice() : prix);
        response.setSubtotal(item.getSubtotal() != null ? item.getSubtotal() : 0);
        response.setPromotionActive(item.getPromotionActive() != null && item.getPromotionActive());
    }

    private double roundMoney(double value) {
        return Math.round(value * 100) / 100.0;
    }

   @PostMapping("/migrate")
    public ResponseEntity<?> migrateSessionCartToUserCart(
            @RequestHeader(value = "X-Session-ID") String sessionId,
            HttpServletRequest request) {
        
        try {
            Long userId = getCurrentUserId();
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "success", false,
                    "message", "Utilisateur non connecté"
                ));
            }

            // Log headers for debugging
            Enumeration<String> headerNames = request.getHeaderNames();
            while (headerNames.hasMoreElements()) {
                String headerName = headerNames.nextElement();
                logger.info("Header {}: {}", headerName, request.getHeader(headerName));
            }

            Panier migratedCart = panierService.migrateSessionCartToUserCart(userId, sessionId);
            
            // Return the new cart with session ID header removed
            return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .body(mapToPanierResponse(migratedCart));
                
        } catch (Exception e) {
            logger.error("Error migrating cart", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    @PostMapping("/items")
    public ResponseEntity<?> addItemToCart(
            @RequestBody PanierItemRequest itemRequest,
            @RequestHeader(value = "X-Session-ID", required = false) String sessionId,
            HttpServletRequest request,
            HttpServletResponse response) {
        
        try {
            // Validate request body
            if (itemRequest == null || itemRequest.getBassinId() == null || itemRequest.getQuantity() <= 0) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Requête invalide"
                ));
            }

            // Get user ID from authentication, not from request body
            Long userId = getCurrentUserId();
            
            // Generate session ID if needed
            if (userId == null && (sessionId == null || sessionId.isEmpty())) {
                sessionId = generateSessionId();
                response.setHeader("X-Session-ID", sessionId);
            }
            
            // Add item to cart
            PanierItem item = panierService.addItemToPanier(userId, sessionId, itemRequest);
            
            // Build response
            Map<String, Object> responseBody = new HashMap<>();
            responseBody.put("success", true);
            responseBody.put("item", convertToItemResponse(item));
            
            // Set headers
            HttpHeaders headers = new HttpHeaders();
            if (userId == null) {
                headers.add("X-Session-ID", item.getPanier().getSessionId());
            }
            
            return new ResponseEntity<>(responseBody, headers, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error adding item to cart", e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}