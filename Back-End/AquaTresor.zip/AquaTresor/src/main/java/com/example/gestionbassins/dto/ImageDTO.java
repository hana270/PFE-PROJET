package com.example.gestionbassins.dto;

/*
public class ImageDTO {
    private Long idImage;
    private String name;
    private String type;
    
	public Long getIdImage() {
		return idImage;
	}
	public void setIdImage(Long idImage) {
		this.idImage = idImage;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

    // Getters and Setters
    
}*/