package com.example.gestionbassins.projections;

public interface ImageProjection {
    Long getIdImage();
    String getName();
    String getType();
}