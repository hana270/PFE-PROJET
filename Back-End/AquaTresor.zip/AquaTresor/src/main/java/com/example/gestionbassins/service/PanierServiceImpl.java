package com.example.gestionbassins.service;

import com.example.gestionbassins.dto.PanierItemRequest;
import com.example.gestionbassins.entities.*;
import com.example.gestionbassins.repos.BassinRepository;
import com.example.gestionbassins.repos.PanierRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PanierServiceImpl implements PanierService {
    
    private final PanierRepository panierRepository;
    private final BassinRepository bassinRepository;

    public PanierServiceImpl(PanierRepository panierRepository, BassinRepository bassinRepository) {
        this.panierRepository = panierRepository;
        this.bassinRepository = bassinRepository;
    }
    
    @Transactional
    public PanierItem addItemToPanier(Long userId, String sessionId, PanierItemRequest itemRequest) {
        if (!itemRequest.isValid()) {
            throw new IllegalArgumentException("Requête panier invalide");
        }

        Panier panier = getOrCreatePanier(userId, sessionId);
        PanierItem item = createPanierItem(itemRequest);
       
     // Make sure user ID is properly set in the panier
        if (userId != null) {
            panier.setUserId(userId);
        }
        
        panier.addItem(item);
        panierRepository.save(panier);
        return item;
    }
    
    @Override
    public void updateItemQuantity(Long userId, String sessionId, Long itemId, int newQuantity) {
        if (newQuantity <= 0) {
            throw new IllegalArgumentException("La quantité doit être positive");
        }
        
        Panier panier = getPanierByUserIdOrSessionId(userId, sessionId);
        PanierItem item = findItemInPanier(panier, itemId);
        
        if (item.getBassin() != null && !validateStock(item.getBassin(), newQuantity)) {
            throw new IllegalStateException("Stock insuffisant");
        }
        
        item.setQuantity(newQuantity);
        panierRepository.save(panier);
    }
    
    @Override
    public void removeItemFromPanier(Long userId, String sessionId, Long itemId) {
        Panier panier = getPanierByUserIdOrSessionId(userId, sessionId);
        panier.getItems().removeIf(item -> item.getId().equals(itemId));
        panierRepository.save(panier);
    }
    
    @Override
    public void clearPanier(Long userId, String sessionId) {
        Panier panier = getPanierByUserIdOrSessionId(userId, sessionId);
        panier.getItems().clear();
        panierRepository.save(panier);
    }
    
    @Override
    public Panier migrateSessionCartToUserCart(Long userId, String sessionId) {
        Panier sessionCart = panierRepository.findFirstBySessionId(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Panier session non trouvé"));
        
        Panier userCart = panierRepository.findFirstByUserId(userId)
                .orElseGet(() -> createNewPanier(userId, null));
        
        sessionCart.getItems().forEach(item -> {
            Optional<PanierItem> existingItem = findMatchingItem(userCart, item);
            if (existingItem.isPresent()) {
                existingItem.get().setQuantity(existingItem.get().getQuantity() + item.getQuantity());
            } else {
                userCart.addItem(item);
            }
        });
        
        panierRepository.delete(sessionCart);
        return panierRepository.save(userCart);
    }
    
    @Override
    public boolean validateStock(Bassin bassin, int requestedQuantity) {
        return bassin.getStock() >= requestedQuantity;
    }
    
    @Override
    public List<PanierItem> getPanierItems(Long panierId, Long userId) {
        Panier panier = panierRepository.findById(panierId)
                .orElseThrow(() -> new IllegalArgumentException("Panier non trouvé"));
        
        if (userId != null && !panier.getUserId().equals(userId)) {
            throw new IllegalArgumentException("Accès non autorisé à ce panier");
        }
        
        return panier.getItems();
    }

    @Override
    public Panier getPanierByUserIdOrSessionId(Long userId, String sessionId) {
        if (userId != null) {
            return panierRepository.findFirstByUserId(userId)
                    .orElseGet(() -> createNewPanier(userId, null));
        } else {
            return panierRepository.findFirstBySessionId(sessionId)
                    .orElseGet(() -> createNewPanier(null, sessionId));
        }
    }


    @Override
    public Panier getOrCreatePanier(Long userId, String sessionId) {
        if (userId != null) {
            return panierRepository.findFirstByUserId(userId)
                    .orElseGet(() -> createNewPanier(userId, null));
        } else {
            return panierRepository.findFirstBySessionId(sessionId)
                    .orElseGet(() -> createNewPanier(null, sessionId));
        }
    }
    
    private Panier createNewPanier(Long userId, String sessionId) {
        Panier panier = new Panier();
        panier.setUserId(userId);
        panier.setSessionId(sessionId);
        return panierRepository.save(panier);
    }
    
    private PanierItem createPanierItem(PanierItemRequest itemRequest) {
        if (itemRequest.getBassinId() != null) {
            Bassin bassin = bassinRepository.findById(itemRequest.getBassinId())
                    .orElseThrow(() -> new IllegalArgumentException("Bassin non trouvé"));
            
            PanierItem item = new PanierItem(bassin, itemRequest.getQuantity());
            
            if (itemRequest.hasPromotion()) {
                item.setPromotionActive(true);
                item.setNomPromotion(itemRequest.getNomPromotion());
                item.setTauxReduction(itemRequest.getTauxReduction());
                item.setPrixPromo(itemRequest.getPrixPromo());
            }
            
            return item;
        } else if (itemRequest.getBassinPersonnaliseId() != null) {
            return new PanierItem(
                itemRequest.getBassinPersonnaliseId(),
                itemRequest.getQuantity(),
                itemRequest.getPrixOriginal()
            );
        }
        
        throw new IllegalArgumentException("L'item doit avoir soit un bassinId soit un bassinPersonnaliseId");
    }
    
    private PanierItem findItemInPanier(Panier panier, Long itemId) {
        return panier.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Article non trouvé dans le panier"));
    }
    
    private Optional<PanierItem> findMatchingItem(Panier panier, PanierItem itemToMatch) {
        return panier.getItems().stream()
                .filter(item -> 
                    (item.getBassin() != null && itemToMatch.getBassin() != null && 
                     item.getBassin().getIdBassin().equals(itemToMatch.getBassin().getIdBassin())) ||
                    (item.getBassinPersonnaliseId() != null && itemToMatch.getBassinPersonnaliseId() != null &&
                     item.getBassinPersonnaliseId().equals(itemToMatch.getBassinPersonnaliseId()))
                )
                .findFirst();
    }
    
    @Override
    public Panier getPanierBySessionId(String sessionId) {
        return panierRepository.findFirstBySessionId(sessionId)
                .orElseGet(() -> createNewPanier(null, sessionId));
    }

    @Override
    public Panier getPanierByUserId(Long userId) {
        return panierRepository.findFirstByUserId(userId)
                .orElseGet(() -> createNewPanier(userId, null));
    }
    
}