package com.example.gestionbassins.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
public class PanierItemRequest {
    private Long bassinId;
    private Long bassinPersonnaliseId;
    private int quantity;
   
    @JsonIgnoreProperties(ignoreUnknown = true)
    private Long userId;
    
    // Price information
    private Double prixOriginal;
    private Double prixPromo;
    
    // Promotion info if applicable
    private Long promotionId;
    private String nomPromotion;
    private Double tauxReduction;
    
    // Validation methods
    public boolean isValid() {
        return (bassinId != null || bassinPersonnaliseId != null) && quantity > 0;
    }
    
    public boolean hasPromotion() {
        return promotionId != null && tauxReduction != null && tauxReduction > 0;
    }
}