package com.example.gestionbassins.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Panier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPanier;
    
    // Store only the user ID instead of a relationship
    @Column(name = "user_id")
    private Long userId;
    
    @Column(unique = true)
    private String sessionId;
    
    @OneToMany(mappedBy = "panier", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<PanierItem> items = new ArrayList<>();
    
    @Transient
    private Double totalPrice;
    
    // Helper methods
    public void removeItem(PanierItem item) {
        items.remove(item);
        item.setPanier(null);
    }
    
    public void clear() {
        items.clear();
    }
    
    public void addItem(PanierItem item) {
        item.setPanier(this);
        this.items.add(item);
    }
    
    public Double getTotalPrice() {
        if (items == null || items.isEmpty()) {
            return 0.0;
        }
        
        return items.stream()
                .mapToDouble(PanierItem::getSubtotal)
                .sum();
    }
}