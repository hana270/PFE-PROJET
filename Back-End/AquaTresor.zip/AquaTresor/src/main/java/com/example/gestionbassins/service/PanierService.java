package com.example.gestionbassins.service;

import com.example.gestionbassins.dto.PanierItemRequest;
import com.example.gestionbassins.entities.*;

import java.util.List;

public interface PanierService {
    PanierItem addItemToPanier(Long userId, String sessionId, PanierItemRequest itemRequest);
    void updateItemQuantity(Long userId, String sessionId, Long itemId, int newQuantity);
    void removeItemFromPanier(Long userId, String sessionId, Long itemId);
    void clearPanier(Long userId, String sessionId);
    Panier migrateSessionCartToUserCart(Long userId, String sessionId);
    boolean validateStock(Bassin bassin, int requestedQuantity);
    List<PanierItem> getPanierItems(Long panierId, Long userId);
    Panier getPanierByUserIdOrSessionId(Long userId, String sessionId);
    
    // Add this method that's missing
    Panier getOrCreatePanier(Long userId, String sessionId);
    Panier getPanierBySessionId(String sessionId);
    Panier getPanierByUserId(Long userId);
}