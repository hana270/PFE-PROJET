package com.example.gestionbassins.dto;

import com.example.gestionbassins.entities.Bassin;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class PanierItemResponse {
    private Long id;
    private int quantity;
    private BassinDTO bassin; 
    private Long bassinPersonnaliseId;
    
    // Price information
    private Double prixOriginal;
    private Double prixPromo;
    private Double customPrice;
    private Double effectivePrice;
    
    // Promotion information
    private Boolean promotionActive;
    private String nomPromotion;
    private Double tauxReduction;
    
    // Additional product info
    private String imageUrl;
    private String nomBassin;
    private String dimensions;
    private String couleur;
    private String materiau;
    
    // Subtotal for this item
    private Double subtotal;
    
    // Accessories for custom products
    private Map<String, Object> accessoires;
    

    private Long userId;
    private String sessionId;
    private Double totalPrice;
    private List<PanierItemResponse> items;
    
    
    private Long bassinId;  // Add this field

    public void setBassinId(Long bassinId) {  // Add this method
        this.bassinId = bassinId;
    }
    
    
    
}