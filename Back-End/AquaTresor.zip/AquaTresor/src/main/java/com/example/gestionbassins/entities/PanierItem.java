package com.example.gestionbassins.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
public class PanierItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "bassin_id")
    private Bassin bassin;

    private Long bassinPersonnaliseId;
    private int quantity;

    // Price fields
    private Double prixOriginal;
    private Double prixPromo;
    private Double customPrice;
    
    // Promotion fields
    private String nomPromotion;
    private Double tauxReduction;
    private Boolean promotionActive = false;

    @ManyToOne
    @JoinColumn(name = "panier_id")
    @JsonBackReference
    private Panier panier;

    // Constructor for bassin items
    public PanierItem(Bassin bassin, int quantity) {
        this.bassin = bassin;
        this.quantity = quantity;
        this.prixOriginal = bassin.getPrix();
        if (bassin.hasActivePromotion()) {
            this.promotionActive = true;
            this.nomPromotion = bassin.getPromotion().getNomPromotion();
            this.tauxReduction = bassin.getPromotion().getTauxReduction();
            this.prixPromo = bassin.getPrixPromotionnel();
        }
    }

    // Constructor for personalized bassin items
    public PanierItem(Long bassinPersonnaliseId, int quantity, Double prixOriginal) {
        this.bassinPersonnaliseId = bassinPersonnaliseId;
        this.quantity = quantity;
        this.prixOriginal = prixOriginal;
    }

    public Double getEffectivePrice() {
        if (promotionActive && prixPromo != null) {
            return prixPromo;
        }
        if (customPrice != null) {
            return customPrice;
        }
        return prixOriginal;
    }

    public Double getSubtotal() {
        Double price = getEffectivePrice();
        return price != null ? price * quantity : 0.0;
    }
    
    public Boolean getPromotionActive() {
        return promotionActive != null ? promotionActive : false;
    }

    public void setPromotionActive(Boolean promotionActive) {
        this.promotionActive = promotionActive;
    }
    // Helper method to get user ID from parent panier
    @Transient
    public Long getUserId() {
        return panier != null ? panier.getUserId() : null;
    }

}