package com.example.gestionbassins.dto;

import com.example.gestionbassins.entities.PanierItem;
import lombok.Data;

import java.util.List;

@Data
public class PanierResponse {
	  private Long id;
	    private Long userId;
	    private String sessionId;
	    private Double totalPrice;
	    private List<PanierItemResponse> items;
}