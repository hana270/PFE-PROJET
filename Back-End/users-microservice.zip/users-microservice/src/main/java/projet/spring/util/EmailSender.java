package projet.spring.util;

public interface EmailSender {
	public void sendEmail(String to, String email);
}
