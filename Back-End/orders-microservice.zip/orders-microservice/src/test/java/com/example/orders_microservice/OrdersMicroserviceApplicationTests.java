package com.example.orders_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
